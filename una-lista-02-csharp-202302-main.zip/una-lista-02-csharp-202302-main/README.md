# una-lista-02-csharp-202302
Atividades 02
